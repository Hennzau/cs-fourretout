package entities;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("bf6bd2ba-8e90-44d7-833e-e9e5a270ea31")
public enum Direction {
    UP,
    DOWN,
    LEFT,
    RIGHT;
}
