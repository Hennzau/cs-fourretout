package entities;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("ead0af13-8fd7-4d86-8a34-683b8b30aa21")
public enum Cell {
    FLOOR,
    WALL,
    TARGET;
}
